package com.example.myapplicationquiz;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Quiz5 extends AppCompatActivity {

    Button next;
    RadioGroup rg;
    RadioButton rb;
    String correctResponse = "Alain Turing";
    int score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz5);

        score = getIntent().getIntExtra("score", 0);

        next = findViewById(R.id.bNext);
        rg = findViewById(R.id.rg);

        new CountDownTimer(30000, 1000) {

            public void onTick(long millisUntilFinished) {
            }

            public void onFinish() {
                Intent i5 = new Intent(getApplicationContext(), Score.class);
                i5.putExtra("score", score);
                startActivity(i5);
                overridePendingTransition(R.anim.exit, R.anim.entry);
                finish();
            }
        }.start();

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (rg.getCheckedRadioButtonId() == -1) {
                    Toast.makeText(getApplicationContext(), "Veuillez choisir une réponse !",
                            Toast.LENGTH_SHORT).show();
                } else {
                    rb = findViewById(rg.getCheckedRadioButtonId());
                    if (rb.getText().toString().equals(correctResponse)) score += 1;

                    Intent i5 = new Intent(getApplicationContext(), Score.class);
                    i5.putExtra("score", score);
                    startActivity(i5);
                    overridePendingTransition(R.anim.exit, R.anim.entry);
                    finish();
                }
            }
        });
    }
}
