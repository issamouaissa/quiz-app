package com.example.myapplicationquiz;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Quiz1 extends AppCompatActivity {

    Button next;
    RadioGroup rg;
    RadioButton rb;
    String correctResponse = "Thomas Alva Edison";
    int score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz1);

        score = getIntent().getIntExtra("score", 0); // Récupération du score

        next = findViewById(R.id.bNext);
        rg = findViewById(R.id.rg);

        // Lancer le compte à rebours de 30 secondes dès que l'activité est créée
        new CountDownTimer(30000, 1000) {

            public void onTick(long millisUntilFinished) {
                // Ce code est exécuté chaque seconde avant la fin du décompte
            }

            public void onFinish() {
                // Ce code est exécuté lorsque le décompte est terminé
                // Charger automatiquement le Quiz 2
                Intent i1 = new Intent(getApplicationContext(), Quiz2.class);
                i1.putExtra("score", score);
                startActivity(i1);
                overridePendingTransition(R.anim.exit, R.anim.entry);
                // Terminer cette activité pour empêcher de revenir en arrière
                finish();
            }
        }.start(); // Démarre le CountDownTimer

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (rg.getCheckedRadioButtonId() == -1) {
                    Toast.makeText(getApplicationContext(), "Veuillez choisir une réponse !",
                            Toast.LENGTH_SHORT).show();
                } else {
                    rb = findViewById(rg.getCheckedRadioButtonId());
                    if (rb.getText().toString().equals(correctResponse)) score += 1;

                    // Arrêter le compte à rebours quand l'utilisateur clique sur Next
                    // pour éviter le passage automatique au Quiz 2
                    Intent i1 = new Intent(getApplicationContext(), Quiz2.class);
                    i1.putExtra("score", score);
                    startActivity(i1);
                    overridePendingTransition(R.anim.exit, R.anim.entry);
                    // Terminer cette activité pour empêcher de revenir en arrière
                    finish();
                }
            }
        });
    }
}